## Release 0.2.0
### Summary
This release adds windows compatibility.

## Release 0.1.2
### Summary

This release updates the documentation to better indicate the puppet\_gem module should be used going forward.

## 2015-06-08 Release 0.1.1
### Summary

This release adds a deprecation warning.

## 2014-10-24 Release 0.1.0
### Summary

This release adds the feature to support `install_options` like the original gem provider. (Requires puppet 3.6.0 or later to work)

### Features
- Add `install_options` provider feature
